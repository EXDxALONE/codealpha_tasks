# Task 1 — Basic Network Sniffer

## 1. Objective

Build a Python program that captures network packets and displays:

- Source IP
- Destination IP
- Protocol
- Source port
- Destination port
- Packet size
- A short payload preview

This implementation uses **Scapy**.

> Run it only on your own computer/network or where you have explicit authorization.

---

## 2. Software required

### Windows
1. Install Python 3.
2. Install Npcap from the official Npcap website.
3. Open Command Prompt/PowerShell.
4. Install Scapy:

```bash
python -m pip install scapy
```

### Linux
Install Scapy:

```bash
python3 -m pip install scapy
```

You may need elevated privileges for packet capture:

```bash
sudo python3 network_sniffer.py
```

---

## 3. Project structure

```text
basic_network_sniffer/
├── network_sniffer.py
├── requirements.txt
└── README.md
```

---

## 4. Run the program

Open the project folder in a terminal.

Windows:

```bash
python network_sniffer.py
```

If your system requires it, run the terminal/IDE with administrator privileges.

Linux:

```bash
sudo python3 network_sniffer.py
```

You should see:

```text
BASIC NETWORK SNIFFER - SCAPY
Capturing packets for educational analysis.
Press Ctrl+C to stop.
```

---

## 5. Generate traffic for testing

Do this on your own computer.

For example:
1. Start the sniffer.
2. Open a normal website in your browser.
3. Or run:

```bash
ping 8.8.8.8
```

4. Watch the terminal for captured packets.
5. Press `Ctrl+C` to stop.

---

## 6. What the code does

### Step 1 — Import Scapy

```python
from scapy.all import sniff, IP, IPv6, TCP, UDP, ICMP, Raw
```

`sniff()` captures packets.

`IP` and `IPv6` represent network-layer packets.

`TCP`, `UDP`, and `ICMP` identify common protocols.

`Raw` lets us inspect application data when a raw payload is present.

### Step 2 — Find source and destination

```python
if IP in packet:
    return packet[IP].src, packet[IP].dst
```

This extracts the source and destination IP addresses.

### Step 3 — Detect protocol

```python
if TCP in packet:
    return "TCP"
```

The program checks whether the packet contains TCP, UDP, ICMP, etc.

### Step 4 — Read ports

TCP and UDP use ports.

Example:

```text
Source port: 53124
Destination port: 443
```

Port `443` commonly indicates HTTPS traffic.

### Step 5 — Read payload safely

The program displays only a short representation:

```python
data = bytes(packet[Raw].load)
preview = repr(data[:limit])
```

This avoids dumping an entire payload to the terminal.

### Step 6 — Capture packets

```python
sniff(filter="ip", prn=analyze_packet, store=False)
```

- `filter="ip"` → focus on IP packets.
- `prn=analyze_packet` → call our analysis function for every packet.
- `store=False` → do not keep all packets in memory.

---

## 7. Example output

Your actual output will differ:

```text
================================================================================
Time        : 15:42:10
Source      : 192.168.1.10
Destination : 142.250.183.14
Protocol    : TCP
Src Port    : 53214
Dst Port    : 443
Packet Size : 517 bytes
Payload     : (no Raw payload)
```

Another packet might look like:

```text
================================================================================
Time        : 15:42:11
Source      : 192.168.1.10
Destination : 8.8.8.8
Protocol    : ICMP
Src Port    : -
Dst Port    : -
Packet Size : 84 bytes
Payload     : (no Raw payload)
```

---

## 8. How to explain this task in your report/viva

### What is a network packet?

A packet is a unit of data transmitted across a network. It contains headers that describe information such as source, destination, protocol, and other control information.

### What is packet sniffing?

Packet sniffing means observing network packets as they pass through an interface for troubleshooting, learning, monitoring, or security analysis.

### What is Scapy?

Scapy is a Python library that can construct, send, receive, capture, and analyze network packets.

### TCP vs UDP

**TCP**
- Connection-oriented
- Reliable delivery
- Uses sequence/acknowledgment mechanisms
- Commonly used by applications such as HTTPS

**UDP**
- Connectionless
- Lower protocol overhead
- Does not provide TCP-style delivery guarantees
- Commonly used for DNS, streaming, and real-time applications

### What is an IP address?

An IP address identifies a network interface/device endpoint at the IP layer.

### What is a port?

A port identifies an application/service endpoint associated with TCP or UDP traffic.

### What is a payload?

The payload is the data carried by a protocol packet beyond the relevant protocol headers.

---

## 9. Task requirements checklist

- [x] Python packet-capture program
- [x] Scapy packet capture
- [x] Packet structure analysis
- [x] Source IP
- [x] Destination IP
- [x] Protocol
- [x] Source/destination ports where applicable
- [x] Packet size
- [x] Payload preview
- [x] Explanation of network data flow
- [x] Explanation of basic protocols
- [x] Test procedure
- [x] Viva/report points

---

## 10. Important limitation

HTTPS encrypts application-layer content. Therefore, seeing TCP traffic to destination port 443 does **not** mean the sniffer can read the website's plaintext contents. This program is primarily demonstrating packet capture and packet-header analysis.

Do not use packet sniffing to capture credentials, private communications, or traffic from networks you do not have permission to inspect.
