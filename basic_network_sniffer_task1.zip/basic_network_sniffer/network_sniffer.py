"""
TASK 1: Basic Network Sniffer
Educational packet-capture program using Scapy.

Use only on a computer/network you own or are authorized to inspect.
The program shows packet metadata and a short payload preview.
"""

from datetime import datetime
from scapy.all import sniff, IP, IPv6, TCP, UDP, ICMP, Raw


def get_endpoints(packet):
    """Return source and destination addresses."""
    if IP in packet:
        return packet[IP].src, packet[IP].dst
    if IPv6 in packet:
        return packet[IPv6].src, packet[IPv6].dst
    return "-", "-"


def get_protocol(packet):
    """Identify the most useful protocol layer in the packet."""
    if TCP in packet:
        return "TCP"
    if UDP in packet:
        return "UDP"
    if ICMP in packet:
        return "ICMP"
    if IP in packet:
        return "IP"
    if IPv6 in packet:
        return "IPv6"
    return packet.__class__.__name__


def get_ports(packet):
    """Return TCP/UDP source and destination ports when available."""
    if TCP in packet:
        return packet[TCP].sport, packet[TCP].dport
    if UDP in packet:
        return packet[UDP].sport, packet[UDP].dport
    return "-", "-"


def payload_preview(packet, limit=80):
    """
    Return a safe, short representation of Raw payload.
    Non-printable bytes are escaped by repr().
    """
    if Raw not in packet:
        return "(no Raw payload)"

    data = bytes(packet[Raw].load)
    preview = repr(data[:limit])
    if len(data) > limit:
        preview += " ..."
    return preview


def analyze_packet(packet):
    """Display the important fields of one captured packet."""
    src, dst = get_endpoints(packet)
    protocol = get_protocol(packet)
    sport, dport = get_ports(packet)
    length = len(packet)
    timestamp = datetime.now().strftime("%H:%M:%S")

    print("\n" + "=" * 80)
    print(f"Time        : {timestamp}")
    print(f"Source      : {src}")
    print(f"Destination : {dst}")
    print(f"Protocol    : {protocol}")
    print(f"Src Port    : {sport}")
    print(f"Dst Port    : {dport}")
    print(f"Packet Size : {length} bytes")
    print(f"Payload     : {payload_preview(packet)}")


def main():
    print("=" * 80)
    print("             BASIC NETWORK SNIFFER - SCAPY")
    print("=" * 80)
    print("Capturing packets for educational analysis.")
    print("Press Ctrl+C to stop.")
    print()

    try:
        # filter="ip" keeps the output focused on IP traffic.
        # count=0 means capture until Ctrl+C.
        sniff(filter="ip", prn=analyze_packet, store=False)

    except PermissionError:
        print("\nPermission denied.")
        print("Run the terminal/IDE with the required packet-capture privileges.")
    except OSError as exc:
        print("\nCould not start packet capture.")
        print("On Windows, install Npcap and try again.")
        print(f"Details: {exc}")
    except KeyboardInterrupt:
        print("\n\nCapture stopped by user.")
        print("Task completed successfully.")


if __name__ == "__main__":
    main()
