"""
Task 4 - Network IDS Log Analyzer

Reads Suricata EVE JSON logs and summarizes alerts.
This is a defensive monitoring tool for an authorized lab/network.
"""

import json
import sys
from collections import Counter
from pathlib import Path


def load_alerts(path):
    alerts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            if event.get("event_type") == "alert":
                alerts.append(event)
    return alerts


def summarize(alerts):
    signatures = Counter()
    sources = Counter()
    destinations = Counter()
    severities = Counter()

    for event in alerts:
        alert = event.get("alert", {})
        signatures[alert.get("signature", "Unknown")] += 1
        sources[event.get("src_ip", "Unknown")] += 1
        destinations[event.get("dest_ip", "Unknown")] += 1
        severities[alert.get("severity", "Unknown")] += 1

    print("=" * 72)
    print("NETWORK IDS ALERT SUMMARY")
    print("=" * 72)
    print(f"Total alerts: {len(alerts)}")

    print("\nTop signatures:")
    for name, count in signatures.most_common():
        print(f"  {count:4}  {name}")

    print("\nTop source IPs:")
    for ip, count in sources.most_common(10):
        print(f"  {count:4}  {ip}")

    print("\nTop destination IPs:")
    for ip, count in destinations.most_common(10):
        print(f"  {count:4}  {ip}")

    print("\nSeverity counts:")
    for severity, count in sorted(severities.items(), key=lambda x: str(x[0])):
        print(f"  {severity}: {count}")


def main():
    if len(sys.argv) != 2:
        print("Usage: python analyze_eve.py path/to/eve.json")
        raise SystemExit(2)

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}")
        raise SystemExit(1)

    alerts = load_alerts(path)
    summarize(alerts)


if __name__ == "__main__":
    main()
