"""
Task 4 - Safe IDS response demonstration.

This does NOT change firewall rules or block real systems.
It demonstrates how an alert can be converted into a response decision.
"""

import json
import sys
from collections import Counter


HIGH_RISK_SIGNATURES = {
    "LAB IDS - TEST-SIGNATURE Detected",
}


def response_for(event):
    alert = event.get("alert", {})
    signature = alert.get("signature", "")
    severity = alert.get("severity")

    if signature in HIGH_RISK_SIGNATURES or severity == 1:
        return "ESCALATE: isolate/review source through approved security workflow"

    if severity in (2, 3):
        return "INVESTIGATE: review source, destination, and related events"

    return "LOG_ONLY"


def main():
    if len(sys.argv) != 2:
        print("Usage: python response_demo.py path/to/eve.json")
        raise SystemExit(2)

    with open(sys.argv[1], "r", encoding="utf-8") as f:
        for line in f:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            if event.get("event_type") == "alert":
                sig = event.get("alert", {}).get("signature", "Unknown")
                print(f"{event.get('src_ip','?')} -> {event.get('dest_ip','?')}")
                print(f"  Alert: {sig}")
                print(f"  Response: {response_for(event)}")


if __name__ == "__main__":
    main()
