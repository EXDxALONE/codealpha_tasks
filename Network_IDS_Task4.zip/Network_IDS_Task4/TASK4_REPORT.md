# TASK 4 — Network Intrusion Detection System

## Goal

Set up a network-based IDS concept using Suricata, create detection rules, inspect alerts, and demonstrate a safe response workflow.

This project is designed for an **authorized lab/own network**. The response component is deliberately non-destructive: it recommends an action rather than changing firewall rules or blocking devices automatically.

## Project files

- `suricata_rules.rules` — custom educational detection rules
- `suricata_lab_config.yaml` — example HOME_NET/output configuration
- `analyze_eve.py` — summarizes Suricata EVE JSON alerts
- `response_demo.py` — maps alerts to defensive response decisions without changing the host
- `sample_eve.json` — sample alert data for testing the Python scripts
- `Secure_IDS_Task4.pptx` — presentation for the assignment
- `TASK4_REPORT.md` — written report

## 1. Install Suricata

Install Suricata using the package appropriate for your operating system.

Official documentation:
https://docs.suricata.io/

Verify:

```bash
suricata --build-info
```

## 2. Identify the network interface

Linux:

```bash
ip addr
```

Windows:

```powershell
Get-NetAdapter
```

Choose the interface that carries your authorized lab traffic.

## 3. Configure HOME_NET

Open your Suricata configuration and set HOME_NET to your lab subnet.

Example:

```yaml
vars:
  address-groups:
    HOME_NET: "[192.168.1.0/24]"
    EXTERNAL_NET: "any"
```

Do not blindly copy the example subnet. Replace it with your actual authorized lab subnet.

## 4. Add the rules

Copy the contents of `suricata_rules.rules` into your local Suricata rules file or include the file from `suricata.yaml`.

The rules detect:
- ICMP echo requests
- New HTTP connections to HOME_NET
- A harmless test string `IDS_TEST` in established HTTP traffic

These signatures are intentionally simple so you can demonstrate the IDS without creating a real attack.

## 5. Validate configuration

Run:

```bash
suricata -T -c /path/to/suricata.yaml
```

A successful configuration test should report that the configuration loaded successfully.

## 6. Start monitoring

A typical lab command is:

```bash
sudo suricata -c /path/to/suricata.yaml -i <interface>
```

Use the exact interface/configuration appropriate for your OS and authorized lab.

Suricata normally writes EVE JSON logs under its configured log directory.

## 7. Generate harmless test traffic

From an authorized lab machine:

```bash
ping <YOUR-LAB-IP>
```

For HTTP testing, use a local test web server that you control, then send a harmless request containing `IDS_TEST`.

Do not use the rules to test against systems you do not own or have permission to monitor.

## 8. Analyze alerts

Once `eve.json` has alerts:

```bash
python analyze_eve.py /path/to/eve.json
```

The script reports:
- Total alert count
- Top signatures
- Top source IPs
- Top destination IPs
- Severity counts

## 9. Demonstrate response

Use:

```bash
python response_demo.py sample_eve.json
```

or your own EVE log.

The demonstration produces decisions such as:
- `INVESTIGATE`
- `ESCALATE`
- `LOG_ONLY`

A production response system should use approved, authenticated automation and change-control processes before blocking hosts or isolating systems.

## 10. What to document

For each alert record:
- Timestamp
- Source IP
- Destination IP
- Source/destination ports
- Protocol
- Signature
- Severity
- Initial assessment
- Response decision
- Resolution/status

## 11. IDS vs IPS

**IDS:** Detects and alerts. It generally does not directly block the traffic.

**IPS:** Sits inline and can prevent/block traffic according to configured rules.

For this assignment, the main system is an IDS. The response demonstration shows how alerts can trigger a controlled security workflow without automatically disrupting real systems.

## 12. Limitations

- Signature rules can produce false positives.
- A rule only detects what it is designed to match.
- Encrypted traffic limits visibility into application contents.
- IDS alerts require investigation and context.
- Automated blocking can cause false-positive outages if poorly designed.

## 13. Final checklist

- [x] Network-based IDS concept
- [x] Suricata selected
- [x] Detection rules created
- [x] Alert logging configured
- [x] Continuous monitoring procedure documented
- [x] Response workflow demonstrated
- [x] Alert visualization/summary provided by Python
- [x] Report and presentation prepared
