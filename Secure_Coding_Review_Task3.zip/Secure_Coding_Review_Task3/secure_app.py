"""
TASK 3: Secure Coding Review - Remediated Example

A small educational Flask + SQLite example demonstrating safer coding
practices. This is still a teaching example, not a complete production
authentication system.
"""

import os
import sqlite3
from flask import Flask, request, abort
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)

# Remediation 1: Read configuration from the environment.
app.config["SECRET_KEY"] = os.environ.get("APP_SECRET_KEY")
if not app.config["SECRET_KEY"]:
    raise RuntimeError("APP_SECRET_KEY environment variable is required")


def get_user(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    # Remediation 2: Parameterized query prevents SQL injection.
    query = "SELECT id, username FROM users WHERE username = ?"
    cursor.execute(query, (username,))

    result = cursor.fetchone()
    conn.close()
    return result


def verify_password(password, password_hash):
    # Remediation 3: Compare a supplied password with a password hash.
    return check_password_hash(password_hash, password)


def create_password_hash(password):
    # Passwords should be stored as strong one-way password hashes.
    return generate_password_hash(password)


@app.route("/user")
def user():
    username = request.args.get("username", "").strip()

    # Basic input validation.
    if not username or len(username) > 100:
        abort(400, description="Invalid username")

    user_record = get_user(username)

    if user_record:
        return f"User found: {user_record[1]}"
    return "User not found", 404


if __name__ == "__main__":
    # Remediation 4: Do not enable debug mode in a deployed application.
    app.run(host="127.0.0.1", port=5000, debug=False)
