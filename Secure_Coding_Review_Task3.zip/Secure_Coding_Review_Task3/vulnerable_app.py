"""
TASK 3: Secure Coding Review - Intentionally Vulnerable Example

This file is for educational code-review practice.
DO NOT deploy it to production.
"""

import sqlite3
from flask import Flask, request

app = Flask(__name__)

# Finding 1: Hard-coded secret
SECRET_KEY = "admin123"

# Finding 2: Debug mode enabled
app.config["DEBUG"] = True


def get_user(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()

    # Finding 3: SQL injection
    query = "SELECT id, username FROM users WHERE username = '" + username + "'"
    cursor.execute(query)

    result = cursor.fetchone()
    conn.close()
    return result


def check_password(password, stored_password):
    # Finding 4: Plain-text password comparison/storage pattern
    return password == stored_password


@app.route("/user")
def user():
    username = request.args.get("username", "")
    user_record = get_user(username)

    if user_record:
        return f"User found: {user_record[1]}"
    return "User not found", 404


if __name__ == "__main__":
    # Finding 5: Flask development server exposed with debug enabled
    app.run(host="0.0.0.0", port=5000, debug=True)
