# TASK 3 — Secure Coding Review

## 1. Selected language and application

**Programming language:** Python  
**Application:** Small Flask web application using SQLite.

The application has a `/user?username=...` endpoint that looks up a user in a SQLite database.

This project intentionally includes several insecure coding patterns so that they can be identified during a security review and then remediated.

> The vulnerable file is for educational review only. Do not deploy it.

---

## 2. Review methods

### Manual code inspection

The code was inspected for:
- Unsafe database queries
- Secrets embedded in source code
- Password handling
- Debug/development configuration
- Input validation
- Unsafe application exposure

### Static analysis

The project can be checked with Bandit:

```bash
python -m pip install bandit
bandit -r .
```

Bandit is a Python static-analysis tool that identifies common security issues in Python source code.

---

## 3. Finding 1 — SQL Injection

### Vulnerable code

```python
query = "SELECT id, username FROM users WHERE username = '" + username + "'"
cursor.execute(query)
```

### Why it is vulnerable

The user's input is concatenated directly into the SQL statement.

An attacker could manipulate the input so that it changes the meaning of the SQL query.

### Risk

- Unauthorized data access
- Data modification in more complex applications
- Authentication bypass in poorly designed systems
- Potential disclosure of sensitive database information

### Severity

**High**

### Remediation

Use a parameterized query:

```python
query = "SELECT id, username FROM users WHERE username = ?"
cursor.execute(query, (username,))
```

The database driver treats the supplied username as data rather than SQL syntax.

---

## 4. Finding 2 — Hard-coded secret

### Vulnerable code

```python
SECRET_KEY = "admin123"
```

### Why it is vulnerable

Secrets stored in source code can be exposed through:
- Source repositories
- Backups
- Logs
- Shared project files
- Compromised developer machines

The example value is also weak and predictable.

### Risk

Potential compromise of application security mechanisms that depend on the secret.

### Severity

**High**

### Remediation

Store secrets outside the source code:

```python
import os

app.config["SECRET_KEY"] = os.environ["APP_SECRET_KEY"]
```

Use a proper secret-management system for production environments.

---

## 5. Finding 3 — Plain-text password handling

### Vulnerable pattern

```python
return password == stored_password
```

This represents a design in which the application could be storing or comparing passwords in plain text.

### Why it is vulnerable

If a database containing plain-text passwords is leaked, attackers immediately obtain users' passwords.

Users often reuse passwords on other services, increasing the impact.

### Risk

- Credential theft
- Account takeover
- Credential reuse attacks

### Severity

**Critical**

### Remediation

Store password hashes, not passwords:

```python
from werkzeug.security import generate_password_hash, check_password_hash

password_hash = generate_password_hash(password)

valid = check_password_hash(password_hash, password)
```

Use a password-hashing function designed for passwords rather than general-purpose hashes such as plain SHA-256.

---

## 6. Finding 4 — Debug mode enabled

### Vulnerable code

```python
app.run(host="0.0.0.0", port=5000, debug=True)
```

### Why it is vulnerable

Debug functionality can expose sensitive diagnostic information and should not be enabled for production deployments.

Binding the development server to all interfaces also unnecessarily exposes the service on the network.

### Risk

- Information disclosure
- Exposure of debugging functionality
- Increased attack surface

### Severity

**Medium to High**, depending on deployment and framework configuration.

### Remediation

Use:

```python
app.run(host="127.0.0.1", port=5000, debug=False)
```

For production, use a properly configured production WSGI server and reverse proxy rather than Flask's development server.

---

## 7. Finding 5 — Insufficient input validation

### Vulnerable pattern

```python
username = request.args.get("username", "")
```

### Why it is weak

The endpoint accepts arbitrary input without basic validation.

Parameterization is the primary SQL-injection defense, but validation is still useful for enforcing application rules and limiting unexpected input.

### Severity

**Medium**

### Remediation

```python
username = request.args.get("username", "").strip()

if not username or len(username) > 100:
    abort(400)
```

Apply validation appropriate to the application's actual username requirements.

---

## 8. Remediation summary

| Finding | Severity | Recommended fix |
|---|---|---|
| SQL injection | High | Parameterized SQL queries |
| Hard-coded secret | High | Environment/secret manager |
| Plain-text password handling | Critical | Strong password hashing |
| Debug mode | Medium/High | Disable debug in deployment |
| Weak input validation | Medium | Validate length/format |

---

## 9. Secure coding best practices

1. Never concatenate untrusted input into SQL.
2. Use parameterized queries or a well-designed ORM.
3. Never store passwords in plain text.
4. Use dedicated password-hashing functions.
5. Keep secrets out of source code.
6. Disable debug mode in production.
7. Validate input according to business requirements.
8. Apply least privilege to database/application accounts.
9. Keep dependencies updated and scan them for known vulnerabilities.
10. Use static analysis during development and CI/CD.
11. Log security-relevant events without logging passwords, tokens, or sensitive secrets.
12. Review security-sensitive code before deployment.

---

## 10. How to perform the review

### Step 1 — Install Python

Check:

```bash
python --version
```

### Step 2 — Install dependencies

```bash
python -m pip install flask werkzeug
```

### Step 3 — Run static analysis

Install Bandit:

```bash
python -m pip install bandit
```

Run:

```bash
bandit -r .
```

The tool may flag issues such as hard-coded credentials and debug/development configuration. Some findings depend on the exact Bandit version and code pattern, so combine static analysis with manual inspection.

### Step 4 — Inspect the vulnerable code

Open:

```text
vulnerable_app.py
```

Look for:
- SQL string concatenation
- Hard-coded secret
- Password handling
- Debug mode
- Missing validation

### Step 5 — Apply fixes

Open:

```text
secure_app.py
```

Compare the vulnerable and remediated versions.

### Step 6 — Re-run static analysis

```bash
bandit -r secure_app.py
```

Then manually confirm that the security fixes are actually correct.

---

## 11. Example secure design

```text
User Input
    ↓
Input Validation
    ↓
Parameterized Database Query
    ↓
Database
    ↓
Safe Response
```

For authentication:

```text
User Password
    ↓
Password Hashing
    ↓
Store Hash
    ↓
Login
    ↓
Verify Password Against Hash
```

---

## 12. Final conclusion

The review identified multiple security weaknesses in the intentionally vulnerable Flask application. The most important issues were SQL injection, unsafe password handling, hard-coded secrets, and production-inappropriate debug configuration.

The remediated version uses parameterized SQL, environment-based configuration, password hashing, input validation, and disabled debug mode.

Static analysis is useful, but it should not replace manual security review. A secure development process combines automated tools, code review, secure design, testing, dependency management, and careful deployment configuration.
